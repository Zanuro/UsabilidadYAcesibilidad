
$(document).ready(function() {
	$(".dropdown-trigger").dropdown();
	$('.collapsible').collapsible();
	$('.carousel.carousel-slider').carousel({
		fullWidth: true
	  });
	$('.tabs').tabs();

});




window.alert('otro');
